import React from 'react';
import { Feather } from 'lucide-react';
import { PhoneMockup } from './PhoneMockup';
import { CelestialPlanets } from './CelestialPlanets';

interface AngelWingsHeroProps {
  onOpenDownload: () => void;
}

export const AngelWingsHero: React.FC<AngelWingsHeroProps> = () => {
  return (
    <section id="hero-wings" className="relative min-h-[920px] lg:min-h-[980px] w-full pt-28 pb-16 flex flex-col items-center justify-center overflow-hidden">
      
      {/* BACKGROUND PLANET ORBITS FROM SCREENSHOT 1 */}
      <CelestialPlanets />

      {/* FOREGROUND HERO CONTENT: PHONE MOCKUP CENTERED WITH COSMIC PLANETS */}
      <div className="relative z-20 flex flex-col items-center mt-6">
        
        {/* Subtle Angelic / Cosmic Kicker */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-black/50 border border-white/10 backdrop-blur-md mb-4 text-xs text-purple-200">
          <Feather size={12} className="text-cyan-300" />
          <span>Seraphic Cycle Tracking & Astral Harmony</span>
          <span className="text-stone-500">·</span>
          <a 
            href="#wings-sanctuary"
            className="text-cyan-300 hover:text-white font-medium flex items-center gap-1 cursor-pointer"
          >
            Explore Wings Sanctuary ↓
          </a>
        </div>

        {/* Central Phone Mockup (from Screenshot 1) */}
        <div id="phone-section">
          <PhoneMockup />
        </div>
      </div>
    </section>
  );
};
